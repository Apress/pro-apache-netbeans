package todo.util;

import java.awt.Dimension;
import javax.swing.JLabel;

public class EmptyStatusBar extends JLabel {

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(0, 0);
    }

    @Override
    public Dimension getMaximumSize() {
        return new Dimension(0, 0);
    } //may not be necessary
}
