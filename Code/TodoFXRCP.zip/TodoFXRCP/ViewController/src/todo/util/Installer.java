package todo.util;

import static java.lang.Thread.sleep;
import javax.swing.UIManager;
import org.openide.modules.OnStart;
import org.openide.windows.OnShowing;

@OnShowing
@OnStart
public class Installer implements Runnable {

    public Installer() {
        System.setProperty("netbeans.winsys.status_line.path", "com/foo/com-foo-MyStatusBar.instance");
    }

    @Override
    public void run() {
        try {
            sleep(500);
        } catch (InterruptedException ex) {
        }
        UIManager.put("EditorTabDisplayerUI", "todo.util.NoTabsTabDisplayerUI");
    }
}
