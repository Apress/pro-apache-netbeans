package todo.viewcontroller;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import javax.swing.SwingUtilities;
import org.openide.util.Exceptions;
import org.openide.util.Lookup;
import org.openide.windows.WindowManager;
import todo.model.ModelException;
import todo.model.Task;
import todo.model.TaskManagerInterface;
import todo.model.ValidationException;
import todo.util.DateUtil;

/**
 *
 * @author ikost
 */
public class TaskMainController implements Initializable {

    @FXML
    private TableView<TaskWrapper> taskTable;
    @FXML
    private TableColumn<TaskWrapper, Integer> priorityColumn;
    @FXML
    private TableColumn<TaskWrapper, String> descriptionColumn;
    @FXML
    private TableColumn<TaskWrapper, Boolean> alertColumn;
    @FXML
    private TableColumn<TaskWrapper, LocalDate> dueDateColumn;
    @FXML
    private Label lblMessage;
    @FXML
    private ToggleButton chkShowCompletedTasks;
    @FXML
    private CheckMenuItem chkMnuShowCompletedTasks;
    @FXML
    private ToggleButton chkSortBy;
    @FXML
    private Button btnMarkAsCompleted;
    @FXML
    private ToggleGroup toggleGroup;

//    private Main mainApp;
    private TaskManagerInterface taskManager;
    private TasksTopComponent tasksTopComponent;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        taskManager = Lookup.getDefault().lookup(TaskManagerInterface.class);
        SwingUtilities.invokeLater(() -> {
            tasksTopComponent = (TasksTopComponent) WindowManager.getDefault().findTopComponent("TasksTopComponent");
        });
        // Add observable list data to the table
        taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(true)));
        taskTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        taskTable.setOnMousePressed(event -> {
            if (event.isPrimaryButtonDown() && event.getClickCount() == 2
                    && taskTable.getSelectionModel().getSelectedIndex() > -1) {
                handleEditTask();
            }
        });
        // Initialize the table
        priorityColumn.setCellValueFactory(cellData -> cellData.getValue().getPriorityProperty().asObject());
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().getDescriptionProperty());
        alertColumn.setCellValueFactory(cellData -> cellData.getValue().getAlertProperty());
        dueDateColumn.setCellValueFactory(cellData -> cellData.getValue().getDueDateProperty());
        dueDateColumn.setCellFactory(column -> {
            return new TableCell<TaskWrapper, LocalDate>() {
                @Override
                protected void updateItem(LocalDate item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || empty) {
                        setText(null);
                        setStyle("");
                    } else {
                        setText(DateUtil.format(item));
                    }
                }
            };
        });
        final String defaultStyle = taskTable.getStyle();
        taskTable.setRowFactory(tableView -> {
            return new TableRow<TaskWrapper>() {
                @Override
                protected void updateItem(TaskWrapper item, boolean empty) {
                    super.updateItem(item, empty);
                    if (!empty) {
                        if (item.isCompleted()) {
                            setStyle("-fx-background-color: #95caff;");
                        } else if (item.isLate()) {
                            setStyle("-fx-background-color: #f06f06;");
                        } else if (item.hasAlert()) {
                            setStyle("-fx-background-color: #ffff00;");
                        } else {
                            setStyle(defaultStyle);
                        }
                    } else {
                        setStyle(defaultStyle);
                    }
                }
            };
        });
        handleShowAlerts();
    }

    /**
     * Called when the user clicks on New Task List.
     */
    @FXML
    private void handleNewTaskList() {
//        FileChooser dlg = new FileChooser();
//        dlg.setTitle("New Task List");
//        dlg.getExtensionFilters().addAll(
//                new ExtensionFilter("Task Lists - HSQLDB Databases (*.script)", "*.script"),
//                new ExtensionFilter("All Files", "*.*")
//        );
//        File dir = new File(taskManager.getParams().getDatabase()).getParentFile();
//        dlg.setInitialDirectory(dir);
//        File selectedFile = dlg.showSaveDialog(getPrimaryStage());
//        if (selectedFile != null) {
//            try {
//                String arq = createOpenDatabase(selectedFile);
//                setStatus("Task list created: " + arq, false);
//            } catch (Exception e) {
//                setStatus("Cannot create task list", true);
//            }
//        }
    }

    /**
     * Called when the user clicks on Open Task List.
     */
    @FXML
    private void handleOpenTaskList() {
//        FileChooser dlg = new FileChooser();
//        dlg.setTitle("Open Task List");
//        dlg.getExtensionFilters().addAll(
//                new ExtensionFilter("Task Lists - HSQLDB Databases (*.script)", "*.script"),
//                new ExtensionFilter("All Files", "*.*")
//        );
//        File dir = new File(taskManager.getParams().getDatabase()).getParentFile();
//        dlg.setInitialDirectory(dir);
//        File selectedFile = dlg.showOpenDialog(mainApp.getPrimaryStage());
//        if (selectedFile != null) {
//            String arq = createOpenDatabase(selectedFile);
//            setStatus("Task List opened: " + arq, false);
////                setStatus("Cannot open task list", true);
//        }
    }

    private String createOpenDatabase(File databaseFile) {
        String fileName = databaseFile.getAbsolutePath();
        if (fileName.startsWith("file:")) {
            fileName = fileName.substring(5);
        }
        if (fileName.endsWith(".script")) {
            fileName = fileName.substring(0, fileName.length() - 7);
        }
//        taskManager.reconnect(fileName);
        taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(true)));
        return fileName;
    }

    /**
     * Called when the user clicks Show Alerts.
     */
    @FXML
    private void handleShowAlerts() {
        List<Task> tasksWithAlert = new ArrayList<>();
        try {
            tasksWithAlert = taskManager.listTasksWithAlert();
        } catch (ModelException ex) {
            Logger.getLogger(TaskMainController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tasksWithAlert.stream().forEach(t -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Alert");
            alert.setHeaderText("Task: " + t.getDescription());
            alert.setContentText("expired on " + DateUtil.format(t.getDueDate()));
            alert.showAndWait();
        });
        if (tasksWithAlert.isEmpty()) {
            setStatus("There are no tasks with alerts for today.", false);
        } else {
            setStatus("There are " + tasksWithAlert.size() + " task(s) with alerts for today.", false);
        }
    }

    @FXML
    private void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About TodoFX");
        alert.setHeaderText("TodoFX - Task List\nRelease 1.0\n\n"
                + "                http://wiki.netbeans.org/TodoFX");
        alert.setContentText("Author: Ioannis Kostaras");
        alert.showAndWait();
    }

    @FXML
    private void handleNewTask() {
        Task tempTask = new Task();
        boolean saveClicked = tasksTopComponent.showTaskDetailsDialog(new TaskWrapper(tempTask));
        if (saveClicked) {
            try {
                taskManager.addTask(tempTask);
            } catch (ValidationException ex) {
                Exceptions.printStackTrace(ex);
            }
            // Add observable list data to the table
            taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(true)));
        }
    }

    @FXML
    private void handleEditTask() {
        TaskWrapper selectedTask = taskTable.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            boolean saveClicked = tasksTopComponent.showTaskDetailsDialog(selectedTask);
            if (saveClicked) {
                try {
                    taskManager.updateTask(selectedTask.getTask());
                } catch (ValidationException ex) {
                    Exceptions.printStackTrace(ex);
                }
                taskTable.refresh();
            }
        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText("No Task Selected");
            alert.setContentText("Please select a task in the table.");

            alert.showAndWait();
        }
    }

    @FXML
    private void handleRemoveTask() {
        ObservableList<TaskWrapper> selectedTasks = taskTable.getSelectionModel().getSelectedItems();
        selectedTasks.stream().forEach(task -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Remove Task");
            alert.setHeaderText("Are you sure you want to remove task? ");
            alert.setContentText(task.getDescription());
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                taskTable.getItems().remove(task);
                taskManager.removeTask(task.getId());
            }
        });
        taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(true)));
    }

    /**
     * Called when the user clicks Show Completed Tasks.
     */
    private void showCompletedTasks(boolean show) {
        if (show) {
            taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(true))
                    .filtered(t -> t.isCompleted()));
        } else {
            taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(true)));
        }
    }

    /**
     * Called when the user clicks on Show Completed Tasks check button.
     */
    @FXML
    private void handleButtonShowCompletedTasks() {
        showCompletedTasks(chkShowCompletedTasks.isSelected());
        chkMnuShowCompletedTasks.setSelected(chkShowCompletedTasks.isSelected());
    }

    /**
     * Called when the user clicks Show Completed Tasks check menu item.
     */
    @FXML
    private void handleMenuItemShowCompletedTasks() {
        showCompletedTasks(chkMnuShowCompletedTasks.isSelected());
        chkShowCompletedTasks.setSelected(chkMnuShowCompletedTasks.isSelected());
    }

    /**
     * Called when the user clicks Sort By Priority/Due Date check button.
     */
    @FXML
    private void handleSortBy() {
        sortBy(chkSortBy.isSelected());
    }

    /**
     * @param byPriority if {@code true} sort tasks by priority, otherwise by
     * due date
     */
    private void sortBy(boolean byPriority) {
        taskTable.setItems(TaskListWrapper.wrap(taskManager.listAllTasks(byPriority)));
        chkSortBy.setSelected(byPriority);
    }

    /**
     * Called when the user clicks Sort By Priority menu item.
     */
    @FXML
    private void handleSortByPriority() {
        sortBy(true);
    }

    /**
     * Called when the user clicks Sort By Due Date menu item.
     */
    @FXML
    private void handleSortByDueDate() {
        sortBy(false);
    }

    /**
     * Called when the user clicks Mark As Completed.
     */
    @FXML
    private void handleMarkAsCompleted() {
        ObservableList<TaskWrapper> selectedTasks = taskTable.getSelectionModel().getSelectedItems();
        selectedTasks.forEach(selectedTask -> {
            if (selectedTask != null) {
                selectedTask.setCompleted(true);
                taskManager.markAsCompleted(selectedTask.getId(), true);
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setHeaderText("No Task Selected");
                alert.setContentText("Select a task first");
                alert.showAndWait();
            }
        });
        taskTable.refresh();
    }

    /**
     * Closes the application.
     */
    @FXML
    private void handleExit() {
        System.exit(0);
    }

//    public void setMainApp(Main mainApp) {
//        this.mainApp = mainApp;
//    }
    public void setStatus(String msg, boolean isError) {
        lblMessage.setText(msg);
        if (isError) {
            lblMessage.setTextFill(Color.RED);
        } else {
            lblMessage.setTextFill(Color.BLACK);
        }
    }

}
