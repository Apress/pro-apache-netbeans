package todo.viewcontroller;

import java.time.LocalDate;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import todo.model.Task;

/**
 * A JavaFX wrapper for Task
 *
 * @author ikost
 */
public class TaskWrapper {

    private final IntegerProperty idProperty;
    private final StringProperty descriptionProperty;
    private final IntegerProperty priorityProperty;
    private final ObjectProperty<LocalDate> dueDateProperty;
    private final BooleanProperty alertProperty;
    private final IntegerProperty daysBeforeProperty;
    private final StringProperty obsProperty;
    private final BooleanProperty completedProperty;
    private final Task task;

    public TaskWrapper(Task task) {
        this.task = task;
        this.idProperty = new SimpleIntegerProperty(task.getId());
        this.descriptionProperty = new SimpleStringProperty(task.getDescription());
        this.descriptionProperty.addListener(
                (ObservableValue<? extends String> observable, String oldValue, String newValue)
                -> task.setDescription(newValue));
        this.priorityProperty = new SimpleIntegerProperty(task.getPriority());
        this.priorityProperty.addListener(
                (ObservableValue<? extends Number> observable, Number oldValue, Number newValue)
                -> task.setPriority(newValue.intValue())
        );
        this.dueDateProperty = new SimpleObjectProperty<>(task.getDueDate());
        this.dueDateProperty.addListener(
                (ObservableValue<? extends LocalDate> observable, LocalDate oldValue, LocalDate newValue)
                -> task.setDueDate(newValue)
        );
        this.alertProperty = new SimpleBooleanProperty(task.getAlert());
        this.alertProperty.addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue)
                -> task.setAlert(newValue)
        );
        this.daysBeforeProperty = new SimpleIntegerProperty(task.getDaysBefore());
        this.daysBeforeProperty.addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue)
                -> task.setDaysBefore(newValue.intValue())
        );
        this.obsProperty = new SimpleStringProperty(task.getObs());
        this.obsProperty.addListener((ObservableValue<? extends String> observable, String oldValue, String newValue)
                -> task.setObs(newValue)
        );
        this.completedProperty = new SimpleBooleanProperty(task.isCompleted());
        this.completedProperty.addListener(
                (ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue)
                -> task.setCompleted(newValue)
        );
    }

    public Task getTask() {
        return task;
    }

    public IntegerProperty getPriorityProperty() {
        return priorityProperty;
    }

    public StringProperty getDescriptionProperty() {
        return descriptionProperty;
    }

    public BooleanProperty getAlertProperty() {
        return alertProperty;
    }

    public ObjectProperty<LocalDate> getDueDateProperty() {
        return dueDateProperty;
    }

    public int getId() {
        return idProperty.get();
    }

    public String getDescription() {
        return descriptionProperty.get();
    }

    public void setDescription(String description) {
        this.descriptionProperty.set(description);
    }

    public int getPriority() {
        return priorityProperty.get();
    }

    public void setPriority(int priority) {
        this.priorityProperty.set(priority);
    }

    public LocalDate getDueDate() {
        return dueDateProperty.get();
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDateProperty.set(dueDate);
    }

    public boolean getAlert() {
        return alertProperty.get();
    }

    public void setAlert(boolean alert) {
        this.alertProperty.set(alert);
    }

    public int getDaysBefore() {
        return daysBeforeProperty.get();
    }

    public void setDaysBefore(int daysBefore) {
        this.daysBeforeProperty.set(daysBefore);
    }

    public void setObs(String obs) {
        this.obsProperty.set(obs);
    }

    public String getObs() {
        return obsProperty.get();
    }

    public void setCompleted(boolean b) {
        this.completedProperty.set(b);
    }

    public boolean isCompleted() {
        return completedProperty.get();
    }

    public boolean isLate() {
        return getTask().isLate();
    }

    public boolean hasAlert() {
        return getTask().hasAlert();
    }

    @Override
    public boolean equals(Object obj) {
        return getTask().equals(obj);
    }

    @Override
    public int hashCode() {
        return getTask().hashCode();
    }

    @Override
    public String toString() {
        return getTask().toString();
    }

}
