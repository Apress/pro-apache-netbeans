package todo.viewcontroller;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import org.openide.util.Lookup;
import todo.model.TaskManagerInterface;
import todo.util.DateUtil;

/**
 * TaskDetailsDialogController
 *
 * @author ikost
 */
public class TaskDetailsDialogController implements Initializable {

    @FXML
    private Label lblHeader;
    @FXML
    private TextField txtDescription;
    @FXML
    private Spinner spPriority;
    @FXML
    private DatePicker dtDueDate;
    @FXML
    private CheckBox chkAlert;
    @FXML
    private Spinner spDaysBefore;
    @FXML
    private Label lblAlert;
    @FXML
    private TextArea txtaObs;
    @FXML
    private CheckBox chkCompleted;
    @FXML
    private Button btnRemoved;
    private TaskWrapper task;
    private Stage dialogStage;
    private boolean isNewTask;
    private boolean saveClicked = false;
    private final SpinnerValueFactory svfPriority = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10);
    private final SpinnerValueFactory svfDaysBefore = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 30);
    private TaskManagerInterface taskManager;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        taskManager = Lookup.getDefault().lookup(TaskManagerInterface.class);
        spPriority.setValueFactory(svfPriority);
        spDaysBefore.setValueFactory(svfDaysBefore);
        chkAlert.setOnAction(event -> {
            spDaysBefore.setDisable(!chkAlert.isSelected());
            lblAlert.setDisable(!chkAlert.isSelected());
        });
        dtDueDate.setPromptText(DateUtil.DATE_PATTERN);
        dtDueDate.setConverter(new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DateUtil.DATE_PATTERN);

            @Override
            public String toString(LocalDate date) {
                return date != null ? dateFormatter.format(date) : "";
            }

            @Override
            public LocalDate fromString(String string) {
                return string == null || string.isEmpty() ? null : LocalDate.parse(string, dateFormatter);
            }
        });
    }

    /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setNewTask(boolean newTask) {
        this.isNewTask = newTask;
        btnRemoved.setDisable(newTask);
        if (isNewTask()) {
            setMessage("Fill in the new task information", false);
        } else {
            setMessage("Changing task information", false);
        }
    }

    public boolean isNewTask() {
        return isNewTask;
    }

    public void setMessage(String msg, boolean isError) {
        lblHeader.setText(msg);
        if (isError) {
            lblHeader.setTextFill(Color.RED);
        } else {
            lblHeader.setTextFill(Color.BLUE);
        }
    }

    public void setTask(TaskWrapper task) {
        this.task = task;
        txtDescription.setText(task.getDescription());
        svfPriority.setValue(task.getPriority());
        chkCompleted.setSelected(task.isCompleted());
        dtDueDate.setValue(task.getDueDate());
        chkAlert.setSelected(task.getAlert());
        spDaysBefore.setDisable(!task.getAlert());
        lblAlert.setDisable(!task.getAlert());
        svfDaysBefore.setValue(task.getDaysBefore());
        txtaObs.setText(task.getObs());
        btnRemoved.setDisable(task.getId() == -1);
    }

    public TaskWrapper getTask() {
        task.setDescription(txtDescription.getText());
        task.setPriority(((Number) spPriority.getValue()).intValue());
        task.setCompleted(chkCompleted.isSelected());
        task.setDueDate(dtDueDate.getValue());
        task.setAlert(chkAlert.isSelected());
        task.setDaysBefore(((Number) spDaysBefore.getValue()).intValue());
        task.setObs(txtaObs.getText());
        return task;
    }

    /**
     * @return {@code true} if the user clicked Save, {@code false} otherwise.
     */
    public boolean isSaveClicked() {
        return saveClicked;
    }

    /**
     * Called when the user clicks Cancel.
     */
    @FXML
    private void handleCancel() {
        dialogStage.close();
    }

    /**
     * Called when the user clicks Remove.
     */
    @FXML
    private void handleRemove() {
        task = getTask();
        saveClicked = false;
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initOwner(dialogStage);
        alert.setTitle("Remove Task");
        alert.setHeaderText("Are you sure you want to remove task? ");
        alert.setContentText(task.getDescription());
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            taskManager.removeTask(task.getId());
        }
        dialogStage.close();
    }

    /**
     * Called when the user clicks Save.
     */
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            task = getTask();
            saveClicked = true;
            dialogStage.close();
        }
    }

    /**
     * Validates the user input in the text fields.
     *
     * @return {@code true} if the input is valid
     */
    private boolean isInputValid() {
        String errorMessage = "";

        if (txtDescription.getText() == null || txtDescription.getText().isEmpty()) {
            errorMessage += "No valid description!\n";
        }

        if (dtDueDate.getValue() == null) {
            errorMessage += "No valid due date!\n";
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }
    }

}
