package todo.viewcontroller;

import java.util.List;
import static java.util.stream.Collectors.toList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import todo.model.Task;

/**
 * A wrapper class.
 * 
 * @author ikost
 */
public final class TaskListWrapper {

    /**
     * @param allTasks a list of tasks
     * @return an ObservableList of TaskWrappers
     */
    public static final ObservableList<TaskWrapper> wrap(List<Task> allTasks) {
        return FXCollections.observableArrayList(allTasks.stream().map(task -> new TaskWrapper(task)).collect(toList()));
    }
}
