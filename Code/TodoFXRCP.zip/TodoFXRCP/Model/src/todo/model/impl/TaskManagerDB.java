package todo.model.impl;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openide.util.lookup.ServiceProvider;
import todo.model.ModelException;
import todo.model.Parameters;
import todo.model.Task;
import todo.model.TaskManagerInterface;
import todo.model.ValidationException;

@ServiceProvider(service = TaskManagerInterface.class)
public final class TaskManagerDB implements TaskManagerInterface {

    private final Parameters params;
    private Connection con;
    private Statement stmt;
    private ResultSet rs;
    private PropertyChangeSupport pcs = null;

    public TaskManagerDB() {
        this(new Parameters());
    }

    private TaskManagerDB(Parameters params) {
        this.params = params;
        connect();
    }

    /**
     * @return a thread-safe PropertyChangeSupport
     */
    private PropertyChangeSupport getPropertyChangeSupport() {
        if (pcs == null) {
            pcs = new PropertyChangeSupport(this);
        }
        return pcs;
    }

    @Override
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        getPropertyChangeSupport().addPropertyChangeListener(listener);
    }

    @Override
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        getPropertyChangeSupport().removePropertyChangeListener(listener);
    }

    public Parameters getParams() {
        return params;
    }

    public void reconnect(String database) {
        disconnect();
        params.setDatabase(database);
        connect();
    }

    private void connect() {
        try {
            Class.forName(params.getJdbcDriver());
            con = DriverManager.getConnection(params.getJdbcUrl(), "sa", "");
            if (!checkTables()) {
                createTables();
            }
        } catch (ClassNotFoundException | SQLException e) {
            Logger.getLogger(TaskManagerDB.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    private boolean checkTables() {
        try {
            String sql = "SELECT COUNT(*) FROM PUBLIC.todo";
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
            return true;
        } catch (SQLException e) {
            return false;
        } finally {
            cleanUp();
        }
    }

    private void createTables() {
        update("CREATE TABLE PUBLIC.todo ("
                + "id IDENTITY, "
                + "description VARCHAR(100), "
                + "priority INTEGER, "
                + "completed BOOLEAN, "
                + "dueDate DATE, "
                + "alert BOOLEAN, "
                + "daysBefore INTEGER, "
                + "obs VARCHAR(250) "
                + ")");
    }

    public void disconnect() {
        try {
            if (con != null) {
                con.close();
            }
            con = null;
        } catch (SQLException e) {
            // ignores the exception
        }
    }

    private void cleanUp() {
        try {
            if (rs != null) {
                rs.close();
            }
            rs = null;
            if (stmt != null) {
                stmt.close();
            }
            stmt = null;
        } catch (SQLException e) {
            // ignores the exception
        }
    }

    private void update(String sql) {
        try {
            stmt = con.createStatement();
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            Logger.getLogger(TaskManagerDB.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            cleanUp();
        }
    }

    private PreparedStatement prepare(String sql) throws SQLException {
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            stmt = pst;
            return pst;
        } finally {
            cleanUp();
        }
    }

    private List<Task> query(String where, String orderBy) {
        List<Task> result = new ArrayList<>();
        try {
            String sql = "SELECT id, description, priority, completed, "
                    + "dueDate, alert, daysBefore, obs FROM PUBLIC.todo ";
            if (where != null) {
                sql += "WHERE " + where + " ";
            }
            if (orderBy != null) {
                sql += "ORDER BY " + orderBy;
            }
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Task task = new Task();
                task.setId(rs.getInt(1));
                task.setDescription(rs.getString(2));
                task.setPriority(rs.getInt(3));
                task.setCompleted(rs.getBoolean(4));
                Date date = rs.getDate(5);
                task.setDueDate(date == null ? LocalDate.now() : date.toLocalDate());
                task.setAlert(rs.getBoolean(6));
                task.setDaysBefore(rs.getInt(7));
                task.setObs(rs.getString(8));
                result.add(task);
            }
        } catch (SQLException e) {
            Logger.getLogger(TaskManagerDB.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            cleanUp();
        }
        return result;
    }

    private void modify(String sql, Task task) {
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            stmt = pst;
            pst.setString(1, task.getDescription());
            pst.setInt(2, task.getPriority());
            pst.setBoolean(3, task.isCompleted());
            if (task.getDueDate() == null) {
                pst.setDate(4, null);
            } else {
                pst.setDate(4, Date.valueOf(task.getDueDate()));
            }
            pst.setBoolean(5, task.getAlert());
            pst.setInt(6, task.getDaysBefore());
            pst.setString(7, task.getObs());
            pst.executeUpdate();
        } catch (SQLException e) {
            Logger.getLogger(TaskManagerDB.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            cleanUp();
        }
    }

    @Override
    public List<Task> listAllTasks(boolean priorityOrDate) {
        return query(null, priorityOrDate
                ? "priority, dueDate, description" : "dueDate, priority, description");
    }

    @Override
    public List<Task> listTasksWithAlert() throws ModelException {
        return query("alert = true AND "
                + "datediff('dd', CURRENT_TIMESTAMP, CAST(dueDate AS TIMESTAMP)) <= daysBefore",
                "dueDate, priority, description");
    }

    @Override
    public void addTask(Task task) throws ValidationException {
        validate(task);
        String sql = "INSERT INTO PUBLIC.todo ("
                + "description, priority, completed, dueDate, alert,"
                + "daysBefore, obs) VALUES (?, ?, ?, ?, ?, ?, ?)";
        modify(sql, task);
    }

    @Override
    public void updateTask(Task task) throws ValidationException {
        validate(task);
        String sql = "UPDATE PUBLIC.todo SET "
                + "description = ?, priority = ?, completed = ?, dueDate = ?, "
                + "alert = ?, daysBefore = ?, obs = ? "
                + "WHERE id = " + task.getId();
        modify(sql, task);
    }

    @Override
    public void markAsCompleted(int id, boolean completed) {
        update("UPDATE PUBLIC.todo SET completed = " + completed + " "
                + "WHERE id = " + id);
    }

    @Override
    public void removeTask(int id) {
        update("DELETE FROM PUBLIC.todo WHERE id = " + id);
    }

    private boolean isEmpty(final String str) {
        return str == null || str.trim().isEmpty();
    }

    private void validate(final Task task) throws ValidationException {
        if (isEmpty(task.getDescription())) {
            throw new ValidationException("Must provide a task description");
        }
    }
}
