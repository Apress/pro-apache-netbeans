package todo.model;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Task
 *
 * @author ikost
 */
public class Task {

    private int id;
    private String description;
    private int priority;
    private LocalDate dueDate;
    private boolean alert;
    private int daysBefore;
    private String obs;
    private boolean completed;

    public Task() {
        this(-1, "", 0, LocalDate.now());
    }

    public Task(int id, String descr, int prio, LocalDate due) {
        this(id, descr, prio, due, false, 0, "");
    }

    public Task(int id, String descr, int prio, LocalDate due, boolean alert, int daysBefore) {
        this(id, descr, prio, due, alert, daysBefore, "");
    }

    public Task(int id, String descr, int prio, LocalDate due, boolean alert, int daysBefore, String obs) {
        this.id = id;
        this.description = descr;
        this.priority = prio;
        this.dueDate = due;
        this.alert = alert;
        this.daysBefore = daysBefore;
        this.obs = obs;
        this.completed = false;
    }

    public boolean isLate() {
        LocalDate dateDue = getDueDate();
        return (dateDue == null) ? false : dateDue.compareTo(LocalDate.now()) < 0;
    }

    public boolean hasAlert() {
        LocalDate dateDue = getDueDate();
        if (!getAlert() || dateDue == null) {
            return false;
        } else {
            int dias = dueDate.getDayOfYear() - LocalDate.now().getDayOfYear();
            return dias <= getDaysBefore();
        }
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public boolean getAlert() {
        return alert;
    }

    public void setAlert(boolean alert) {
        this.alert = alert;
    }

    public int getDaysBefore() {
        return daysBefore;
    }

    public void setDaysBefore(int daysBefore) {
        this.daysBefore = daysBefore;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Task other = (Task) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Task{" + "id=" + id + ", description=" + description
                + ", priority=" + priority + ", dueDate=" + dueDate
                + ", alert=" + alert + ", daysBefore=" + daysBefore
                + ", obs=" + obs + ", completed=" + completed + '}';
    }

}
