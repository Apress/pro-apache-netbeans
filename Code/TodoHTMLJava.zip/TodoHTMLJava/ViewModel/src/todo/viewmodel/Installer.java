package todo.viewmodel;

import net.java.html.boot.BrowserBuilder;
import org.openide.modules.OnStart;

//@OnStart
public final class Installer implements Runnable {

    @Override
    public void run() {
        BrowserBuilder.newBrowser().
            loadPage("Tasks.html").
            loadClass(TasksCntrl.class).
            invoke("onPageLoad").
            showAndWait();
//        TasksCntrl.onPageLoad();
    }
    
}
