package todo.controller.options;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.openide.awt.ActionID;
import org.openide.awt.ActionReference;
import org.openide.awt.ActionReferences;
import org.openide.awt.ActionRegistration;
import org.openide.util.NbBundle.Messages;
import org.openide.windows.WindowManager;
import todo.view.TasksTopComponent;

@ActionID(
        category = "Options",
        id = "todo.controller.options.ShowAlertsAction"
)
@ActionRegistration(
        iconBase = "todo/controller/options/showwarn_tsk.gif",
        displayName = "#CTL_ShowAlertsAction"
)
@ActionReferences({
    @ActionReference(path = "Menu/Options", position = 40),
    @ActionReference(path = "Toolbars/Options", position = 40),
    @ActionReference(path = "Shortcuts", name = "F9")
})
@Messages("CTL_ShowAlertsAction=Show Alerts...")
public final class ShowAlertsAction implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent evt) {
        TasksTopComponent tasksTopComponent = (TasksTopComponent) WindowManager.getDefault().findTopComponent(
                "TasksTopComponent");
        tasksTopComponent.displayAlerts(true);
    }
}
