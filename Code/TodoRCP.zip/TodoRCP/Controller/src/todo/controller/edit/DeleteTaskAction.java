package todo.controller.edit;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import org.openide.awt.ActionID;
import org.openide.awt.ActionReference;
import org.openide.awt.ActionReferences;
import org.openide.awt.ActionRegistration;
import org.openide.util.Lookup;
import org.openide.util.NbBundle.Messages;
import todo.model.Task;
import todo.model.TaskManagerInterface;

@ActionID(
        category = "Edit",
        id = "todo.controller.edit.DeleteTaskAction"
)
@ActionRegistration(
        iconBase = "todo/controller/edit/delete_obj.gif",
        displayName = "#CTL_DeleteTaskAction"
)
@ActionReferences({
    @ActionReference(path = "Menu/Edit", position = 30),
    @ActionReference(path = "Toolbars/Edit", position = 30),
    @ActionReference(path = "Shortcuts", name = "DELETE")
})
@Messages("CTL_DeleteTaskAction=Remove Task")
public final class DeleteTaskAction implements ActionListener {

    private final List<Task> context;
    private final TaskManagerInterface taskManager;

    public DeleteTaskAction(List<Task> context) {
        this.context = context;
        this.taskManager
                = Lookup.getDefault().lookup(TaskManagerInterface.class);
    }

    @Override
    public void actionPerformed(ActionEvent ev) {
        for (Task task : context) {
            int response = JOptionPane.showConfirmDialog(null,
                    "Are you sure you want to remove task\n["
                    + task.getDescription() + "] ?",
                    "Remove Task",
                    JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                taskManager.removeTask(task.getId());
            }
        }
    }
}
