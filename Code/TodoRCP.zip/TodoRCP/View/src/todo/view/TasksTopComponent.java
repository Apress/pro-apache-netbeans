package todo.view;

import java.text.DateFormat;
import java.util.Collection;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;
import org.netbeans.api.settings.ConvertAsProperties;
import org.netbeans.swing.etable.ETableColumn;
import org.netbeans.swing.etable.ETableColumnModel;
import org.openide.awt.*;
import org.openide.explorer.ExplorerManager;
import org.openide.explorer.ExplorerUtils;
import org.openide.explorer.view.OutlineView;
import org.openide.nodes.AbstractNode;
import org.openide.nodes.Children;
import org.openide.util.Lookup;
import org.openide.windows.TopComponent;
import org.openide.util.NbBundle.Messages;
import todo.model.ModelException;
import todo.model.Task;
import todo.model.TaskManagerInterface;

/**
 * Top component which displays tasks.
 */
@ConvertAsProperties(
        dtd = "-//todo.view//Tasks//EN",
        autostore = false
)
@TopComponent.Description(
        preferredID = "TasksTopComponent",
        //iconBase="SET/PATH/TO/ICON/HERE",
        persistenceType = TopComponent.PERSISTENCE_ALWAYS
)
@TopComponent.Registration(mode = "editor", openAtStartup = true)
@ActionID(category = "Window", id = "todo.view.TasksTopComponent")
@ActionReference(path = "Menu/Window" /*, position = 333 */)
@TopComponent.OpenActionRegistration(
        displayName = "#CTL_TasksAction",
        preferredID = "TasksTopComponent"
)
@Messages({
    "CTL_TasksAction=Tasks",
    "CTL_TasksTopComponent=Tasks Window",
    "HINT_TasksTopComponent=This is a Tasks window"
})
public final class TasksTopComponent extends TopComponent implements ExplorerManager.Provider {

    private final ExplorerManager em = new ExplorerManager();
    private final OutlineView ovTasks;

    public TasksTopComponent() {
        initComponents();
        setName(Bundle.CTL_TasksTopComponent());
        setToolTipText(Bundle.HINT_TasksTopComponent());
        putClientProperty(TopComponent.PROP_CLOSING_DISABLED, Boolean.TRUE);
        ovTasks = (OutlineView) outlineView;

        //Set the columns of the outline view,
        //using the name of the property
        //followed by the text to be displayed in the column header
        ovTasks.setPropertyColumns(
                "priority", "Priority",
                "description", "Task",
                "alert", "Alert",
                "dueDate", "Due Date");

        //Hide the root node, since we only care about the children:
        ovTasks.getOutline().setRootVisible(false);
        TableColumnModel columnModel = ovTasks.getOutline().getColumnModel();
        ETableColumn column = (ETableColumn) columnModel.getColumn(0);
        ((ETableColumnModel) columnModel).setColumnHidden(column, true);
        em.setRootContext(new AbstractNode(Children.create(new TaskChildFactory(), true))); // asynchronously
        associateLookup(ExplorerUtils.createLookup(em, getActionMap()));
    }

    @Override
    public ExplorerManager getExplorerManager() {
        return em;
    }

    public void sortBy(final String field, final boolean ascending) {
        Utilities.sortBy((OutlineView) outlineView, field, ascending);
    }

    public void setQuickFilter(int column, Object filter) {
        ovTasks.getOutline().setQuickFilter(column, filter);
    }

    public void unsetQuickFilter() {
        ovTasks.getOutline().unsetQuickFilter();
    }

    public void displayAlerts(boolean displayDialog) {
        StatusBar statusBar = null;
        TaskManagerInterface taskManager = Lookup.getDefault().lookup(TaskManagerInterface.class);
        Collection<? extends StatusLineElementProvider> lookupAll = Lookup.getDefault().lookupAll(StatusLineElementProvider.class);
        for (StatusLineElementProvider lookup : lookupAll) {
            if (lookup instanceof StatusBar) {
                statusBar = (StatusBar) lookup;
                break;
            }
        }
        try {
            List<Task> tasks = taskManager.listTasksWithAlert();
            if (displayDialog) {
                for (Task aTask : tasks) {
                    DateFormat df = DateFormat.getDateInstance();
                    JOptionPane.showMessageDialog(null,
                            "This task has less than " + aTask.getDaysBefore()
                            + " days left:\n"
                            + "[" + aTask.getDescription() + "]\n"
                            + "the due date is " + df.format(aTask.getDueDate()) + "\n",
                            "Alert", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            if (statusBar != null) {
                if (tasks.isEmpty()) {
                    statusBar.setMessage(StatusBar.STATUS_MSG, false);
                } else {
                    statusBar.setMessage("There are " + tasks.size() + " task alert(s) for today.", false);
                }
            }
        } catch (ModelException e) {
            if (statusBar != null) {
                statusBar.setMessage(e.getMessage(), true);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        outlineView = new OutlineView();

        setLayout(new java.awt.BorderLayout());
        add(outlineView, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane outlineView;
    // End of variables declaration//GEN-END:variables
    @Override
    public void componentOpened() {
        displayAlerts(true);
    }

    @Override
    public void componentClosed() {
        // TODO add custom code on component closing
    }

    void writeProperties(java.util.Properties p) {
        // better to version settings since initial version as advocated at
        // http://wiki.apidesign.org/wiki/PropertyFiles
        p.setProperty("version", "1.0");
        // TODO store your settings
    }

    void readProperties(java.util.Properties p) {
        String version = p.getProperty("version");
        // TODO read your settings according to their version
    }
}
