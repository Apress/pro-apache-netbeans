package todo.view;

import java.beans.IntrospectionException;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import org.openide.nodes.BeanNode;
import org.openide.nodes.Children;
import org.openide.util.lookup.Lookups;
import todo.model.Task;

class TaskNode extends BeanNode<Task> {

    private final transient PropertyChangeListener pcl = new PropertyChangeListener() {

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            firePropertySetsChange(null, getPropertySets());
        }
    };

    public TaskNode(Task bean) throws IntrospectionException {
        super(bean, Children.LEAF, Lookups.singleton(bean));
        bean.addPropertyChangeListener(pcl);
    }
}
