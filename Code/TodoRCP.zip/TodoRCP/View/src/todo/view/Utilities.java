package todo.view;

import javax.swing.event.TableModelEvent;
import javax.swing.table.TableModel;
import org.netbeans.swing.etable.ETableColumn;
import org.netbeans.swing.etable.ETableColumnModel;
import org.openide.explorer.view.OutlineView;

/**
 *
 * @author ikost
 */
public final class Utilities {

    private Utilities() {
    }

    /**
     * Sort the outline view {@code ov} on the given {@code field}.
     *
     * @param ov outline view to sort
     * @param field to sort upon
     * @param ascending if {@code true} then the list is sorted in ascending
     * order, if {@code false} in descending order.
     */
    public static void sortBy(final OutlineView ov, final String field, final boolean ascending) {
        ETableColumnModel columnModel = (ETableColumnModel) ov.getOutline().getColumnModel();
        int columnCount = columnModel.getColumnCount();
        columnModel.clearSortedColumns();
        for (int i = 0; i < columnCount; i++) {
            ETableColumn column = (ETableColumn) columnModel.getColumn(i);
            if (column.getHeaderValue().equals(field)) {
                columnModel.setColumnSorted(column, ascending, 1);
            }
        }
        TableModel model = ov.getOutline().getModel();
        ov.getOutline().tableChanged(new TableModelEvent(model, 0, model.getRowCount()));
    }
}
