package todo.view;

import java.beans.IntrospectionException;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import org.openide.nodes.ChildFactory;
import org.openide.nodes.Node;
import org.openide.util.Exceptions;
import org.openide.util.Lookup;
import todo.model.Task;
import todo.model.TaskManagerInterface;

class TaskChildFactory extends ChildFactory<Task> {

    private TaskManagerInterface taskManager;
    private final transient PropertyChangeListener pcl = new PropertyChangeListener() {

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            refresh(true);
        }
    };

    public TaskChildFactory() {
        taskManager = Lookup.getDefault().lookup(TaskManagerInterface.class);
        taskManager.addPropertyChangeListener(pcl);
    }

    @Override
    protected boolean createKeys(final List<Task> toPopulate) {
        taskManager = Lookup.getDefault().lookup(TaskManagerInterface.class);
        toPopulate.addAll(taskManager.listAllTasks(true));
        return true;
    }

    @Override
    protected Node createNodeForKey(final Task key) {
        TaskNode taskNode = null;
        try {
            taskNode = new TaskNode(key);
        } catch (IntrospectionException ex) {
            Exceptions.printStackTrace(ex);
        }
        return taskNode;
    }
}
