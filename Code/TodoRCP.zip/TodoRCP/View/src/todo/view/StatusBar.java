package todo.view;

import java.awt.Color;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JLabel;
import org.openide.awt.StatusLineElementProvider;
import org.openide.util.Lookup;
import org.openide.util.lookup.ServiceProvider;
import org.openide.windows.WindowManager;
import todo.model.Task;
import todo.model.TaskManagerInterface;

/**
 * The application's status bar.
 */
@ServiceProvider(service = StatusLineElementProvider.class, position = 1)
public class StatusBar implements StatusLineElementProvider {

    private final transient PropertyChangeListener pcl = new PropertyChangeListener() {

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            TasksTopComponent tasksTopComponent
                    = (TasksTopComponent) WindowManager.getDefault().findTopComponent("TasksTopComponent");
            tasksTopComponent.displayAlerts(false);
            if (evt.getSource() instanceof TaskManagerInterface) {
                listenToTaskChanges();
            }
        }
    };
    private final TaskManagerInterface taskManager;
    private final JLabel label = new JLabel(STATUS_MSG);
    public static final String STATUS_MSG = "There are no task alerts for today.";

    public StatusBar() {
        taskManager = Lookup.getDefault().lookup(TaskManagerInterface.class);
        taskManager.addPropertyChangeListener(pcl);
        listenToTaskChanges();
    }

    private void listenToTaskChanges() {
        for (Task task : taskManager.listAllTasks(false)) {
            task.removePropertyChangeListener(pcl);
            task.addPropertyChangeListener(pcl);
        }
    }

    public void setMessage(String msg, boolean error) {
        if (msg != null) {
            label.setText(msg);
            label.setForeground(error ? Color.red : Color.BLACK);
        }
    }

    @Override
    public Component getStatusLineElement() {
        return label;
    }
}
